import unittest
from TestUtils import TestLexer

class LexerSuite(unittest.TestCase):
      
    def test_lơercase_identifier(self):
        """test identifiers"""
        self.assertTrue(TestLexer.test("(* asd(*as*)aaaa(**)","abc,<EOF>",101))
