import unittest
from TestUtils import TestParser

class ParserSuite(unittest.TestCase):
    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """
                    Function foo():integer;
                        Begin
                         END
                    var x,y: real; 
                        z : integer;
                    var m:integer;
                    var a,b: real; 
                        c : integer;
        """
        expect = "Error on line 7 col 16: ;"
        self.assertTrue(TestParser.test(input,expect,201))
